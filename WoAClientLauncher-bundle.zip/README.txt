﻿Wrath of Azeroth Launcher

Extract this bundle into your Wrath 3.3.5a client folder beside Wow.exe.
Run WoAClientLauncher.exe and select Update & Play before entering the realm.
The launcher verifies and installs the listed addon packages and client files.
The launcher also writes the realm login address from the update manifest to each installed locale's realmlist.wtf.
