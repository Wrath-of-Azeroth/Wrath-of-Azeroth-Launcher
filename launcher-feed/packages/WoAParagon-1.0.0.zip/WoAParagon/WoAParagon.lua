local SPELL_PARAGON = 9000200
local PREFIX = "WoAParagon"
local addonCommandSequence = 0
local MAX_PARAGON_LEVEL = 20000
local syncPending = false
local syncElapsed = 0
local syncTimedOut = false
local waitingSequence = nil
local waitingCommand = nil
local commandElapsed = 0
local ART_WIDTH, ART_HEIGHT = 1681, 936
local TEXTURE_WIDTH, TEXTURE_HEIGHT = 2048, 1024
local BRANCHES = {
    { name = "Caster", key = "caster", color = { 0.20, 0.68, 1.00 }, y = 207 },
    { name = "Melee", key = "melee", color = { 1.00, 0.24, 0.16 }, y = 358 },
    { name = "Defensive", key = "defensive", color = { 1.00, 0.68, 0.14 }, y = 506 },
    { name = "Utility", key = "utility", color = { 0.10, 0.86, 0.81 }, y = 659 },
}
local NODE_X = { 286, 354, 423, 491, 560, 629, 698, 766, 834, 902, 970, 1037, 1105, 1173, 1243 }
local NODE_EFFECTS = {
    caster = {
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+1% spell damage and spell healing" end,
        function() return "+2% spell damage and spell healing" end,
        function() return "Adds haste rating equal to 10% haste (melee, ranged, and spell)" end,
    },
    melee = {
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+1% physical damage" end,
        function() return "+2% physical damage" end,
        function() return "Adds haste rating equal to 10% haste (melee, ranged, and spell)" end,
    },
    defensive = {
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+15 to all resistances" end,
        function() return "+40 to all resistances" end,
    },
    utility = {
        function() return "+10% out-of-combat health and mana regeneration" end,
        function() return "+10% out-of-combat health and mana regeneration" end,
        function() return "+10% out-of-combat health and mana regeneration" end,
        function() return "+10% out-of-combat health and mana regeneration" end,
        function() return "+10% out-of-combat health and mana regeneration" end,
        function() return "Reduces stun, root, and movement-impairing effect duration by 18%" end,
        function() return "Reduces stun, root, and movement-impairing effect duration by 18%" end,
        function() return "Reduces stun, root, and movement-impairing effect duration by 18%" end,
        function() return "Reduces stun, root, and movement-impairing effect duration by 18%" end,
        function() return "Reduces stun, root, and movement-impairing effect duration by 18%" end,
        function() return "+5% movement speed" end,
        function() return "+5% movement speed" end,
        function() return "+5% movement speed" end,
        function() return "+5% movement speed" end,
        function() return "+5% movement speed" end,
    },
}

WoAParagonDB = WoAParagonDB or {}
local progress = { characterLevel = 0, level = 0, currentXp = "0", xpToNext = "0",
    caster = 0, melee = 0, defensive = 0, utility = 0, core = 0 }

local function getBranchRanks(key)
    return math.max(0, math.min(15, tonumber(progress[key]) or 0))
end

local function getUnspentPoints()
    local spent = getBranchRanks("caster") + getBranchRanks("melee") +
        getBranchRanks("defensive") + getBranchRanks("utility") + math.max(0, tonumber(progress.core) or 0)
    return math.max(0, (tonumber(progress.level) or 0) - spent)
end

local function sendParagonCommand(command)
    if not UnitName("player") then return end
    addonCommandSequence = (addonCommandSequence + 1) % 10000
    if addonCommandSequence == 0 then addonCommandSequence = 1 end
    -- AzerothCore's addon-command parser expects the prefix and the command
    -- opcode to be separated by exactly one tab. SendAddonMessage supplies
    -- that separator between its prefix and message, so the body must not
    -- start with another tab.
    SendAddonMessage("AzerothCore", "i" .. string.format("%04d", addonCommandSequence) .. "paragon " .. command,
        "WHISPER", UnitName("player"))
    return addonCommandSequence
end

local refreshTree, refreshXpBar
local function requestProgress()
    -- Treat each sync as authoritative. Clear old branch state while waiting so
    -- stale data from another character can never make the tree look purchased.
    progress.characterLevel = UnitLevel("player") or 0
    progress.level = 0
    progress.currentXp, progress.xpToNext = "0", "0"
    progress.caster, progress.melee, progress.defensive, progress.utility, progress.core = 0, 0, 0, 0, 0
    syncPending = true
    syncElapsed = 0
    syncTimedOut = false
    commandElapsed = 0
    if refreshTree then refreshTree() end
    if refreshXpBar then refreshXpBar() end
    waitingCommand = "sync"
    waitingSequence = sendParagonCommand("sync")
end

local screenWidth, screenHeight = UIParent:GetWidth(), UIParent:GetHeight()
local aspect = ART_WIDTH / ART_HEIGHT
local width = math.min(screenWidth * 0.96, screenHeight * 0.96 * aspect) * 0.5
local height = width / aspect
local frame = CreateFrame("Frame", "WoAParagonFrame", UIParent)
frame:SetSize(width, height)
frame:SetPoint("CENTER")
frame:SetFrameStrata("DIALOG")
frame:SetMovable(true)
frame:SetClampedToScreen(true)
frame:EnableMouse(true)
frame:Hide()

local art = frame:CreateTexture(nil, "BACKGROUND")
art:SetTexture("Interface\\AddOns\\WoAParagon\\ParagonTreeClean.blp")
art:SetTexCoord(0, ART_WIDTH / TEXTURE_WIDTH, 0, ART_HEIGHT / TEXTURE_HEIGHT)
art:SetAllPoints(frame)

local function addHotspot(x, y, nodeWidth, nodeHeight, onEnter)
    local button = CreateFrame("Button", nil, frame)
    button:SetSize(width * nodeWidth / ART_WIDTH, height * nodeHeight / ART_HEIGHT)
    button:SetPoint("CENTER", frame, "TOPLEFT", width * x / ART_WIDTH, -height * y / ART_HEIGHT)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        onEnter(self)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return button
end

local function requestPurchase(branch)
    if progress.characterLevel < 80 then return end
    if waitingSequence then
        UIErrorsFrame:AddMessage("Waiting for the previous Paragon update.", 1, 0.75, 0.2, 1)
        return
    end
    if getUnspentPoints() <= 0 then return end
    waitingCommand = "purchase"
    waitingSequence = sendParagonCommand("buy " .. branch)
    commandElapsed = 0
end

local nodeStates = {}
local function createNodeState(button, lockSizeFactor, withLock)
    lockSizeFactor = lockSizeFactor or 0.78
    if withLock == nil then withLock = true end
    local dim = CreateFrame("Frame", nil, button)
    dim:SetSize(button:GetWidth(), button:GetHeight())
    dim:SetPoint("CENTER", button, "CENTER")
    dim:SetFrameLevel(button:GetFrameLevel() + 5)
    dim:EnableMouse(false)
    local circleRows = { 3, 5, 7, 9, 11, 11, 11, 9, 7, 5, 3 }
    local cellSize = button:GetWidth() * 1.08 / 11
    for row, cells in ipairs(circleRows) do
        local firstCell = math.floor((11 - cells) / 2) + 1
        for column = firstCell, firstCell + cells - 1 do
            local pixel = dim:CreateTexture(nil, "OVERLAY")
            pixel:SetTexture("Interface\\Buttons\\WHITE8X8")
            pixel:SetVertexColor(0.005, 0.008, 0.02, 0.58)
            pixel:SetSize(cellSize + 0.3, cellSize + 0.3)
            pixel:SetPoint("CENTER", dim, "CENTER",
                (column - 6) * cellSize, (6 - row) * cellSize)
        end
    end
    local lockParts = {}
    if withLock then
        local iconSize = button:GetHeight() * lockSizeFactor
        -- Reuse the earlier simple blue padlock icon on top of the dim overlay.
        local lockIcon = dim:CreateTexture(nil, "OVERLAY", nil, 7)
        lockIcon:SetTexture("Interface\\AddOns\\WoAParagon\\ParagonLock.tga")
        lockIcon:SetSize(iconSize * 0.92, iconSize * 0.92)
        lockIcon:SetPoint("CENTER", dim, "CENTER")
        lockIcon:SetVertexColor(0.88, 0.92, 1.0, 1)
        table.insert(lockParts, lockIcon)
    end
    local lock = {}
    function lock:Show()
        for _, part in ipairs(lockParts) do part:Show() end
    end
    function lock:Hide()
        for _, part in ipairs(lockParts) do part:Hide() end
    end
    return { dim = dim, lock = lock }
end

for _, branch in ipairs(BRANCHES) do
    nodeStates[branch.key] = {}
    for rank = 1, 15 do
        local currentBranch, currentRank = branch, rank
        local button = addHotspot(NODE_X[currentRank], currentBranch.y, 58, 66, function(self)
            local branch = self.paragonBranch
            local rank = self.paragonRank
            local definition = BRANCHES[branch == "caster" and 1 or branch == "melee" and 2 or branch == "defensive" and 3 or 4]
            local bought = getBranchRanks(branch)
            GameTooltip:SetText(definition.name .. " Upgrade " .. rank,
                definition.color[1], definition.color[2], definition.color[3])
            GameTooltip:AddLine(NODE_EFFECTS[branch][rank](), 0.55, 0.9, 1, true)
            if rank <= bought then
                GameTooltip:AddLine("Purchased", 0.3, 1, 0.35)
            elseif rank == bought + 1 then
                if progress.characterLevel < 80 then
                    GameTooltip:AddLine("Paragon progress activates at level 80.", 1, 0.75, 0.2, true)
                else
                    if getUnspentPoints() > 0 then
                        GameTooltip:AddLine("Click to purchase for 1 Paragon point.", 0.7, 0.85, 1, true)
                    else
                        GameTooltip:AddLine("Requires 1 unspent Paragon point.", 1, 0.75, 0.2, true)
                    end
                end
            else
                GameTooltip:AddLine("Locked: purchase the previous node first.", 1, 0.45, 0.35, true)
            end
        end)
        -- Store node identity on the button so hover and click handlers always
        -- read the exact branch/rank represented by that widget.
        button.paragonBranch = currentBranch.key
        button.paragonRank = currentRank
        button.paragonBranchName = currentBranch.name
        button:SetScript("OnClick", function(self)
            if syncPending or waitingSequence then
                UIErrorsFrame:AddMessage("Waiting for this character's Paragon data.", 1, 0.75, 0.2, 1)
                return
            end
            local bought = getBranchRanks(self.paragonBranch)
            if self.paragonRank <= bought then
                UIErrorsFrame:AddMessage(self.paragonBranchName .. " " .. self.paragonRank .. " is already purchased.", 1, 0.8, 0.2, 1)
                return
            end
            if self.paragonRank > bought + 1 then
                UIErrorsFrame:AddMessage("Purchase the previous " .. self.paragonBranchName .. " node first.", 1, 0.45, 0.35, 1)
                return
            end
            if progress.characterLevel < 80 then
                UIErrorsFrame:AddMessage("Paragon upgrades unlock at level 80.", 1, 0.75, 0.2, 1)
                return
            end
            if getUnspentPoints() <= 0 then
                UIErrorsFrame:AddMessage("You have no unspent Paragon points.", 1, 0.45, 0.35, 1)
                return
            end
            UIErrorsFrame:AddMessage("Requesting " .. self.paragonBranchName .. " upgrade " .. self.paragonRank .. "...", 0.35, 0.75, 1, 1)
            requestPurchase(self.paragonBranch)
        end)
        nodeStates[branch.key][rank] = createNodeState(button, nil, rank > 1)
    end
end

local coreButton = addHotspot(1504, 452, 190, 200, function()
    GameTooltip:SetText("Core Upgrade", 0.45, 0.75, 1.00)
    if progress.core > 0 then
        local compoundedBonus = ((1.01 ^ progress.core) - 1) * 100
        GameTooltip:AddLine("Current rank: " .. progress.core .. " (" .. string.format("%.2f%%", compoundedBonus) .. " compounded bonus)", 0.45, 1, 0.55, true)
    end
    GameTooltip:AddLine("Unlock after 45 branch-node purchases.", 0.9, 0.9, 0.9, true)
    GameTooltip:AddLine("Each rank compounds a further 1% to Strength, Agility, Intellect, Spirit, Stamina, and armor.", 0.65, 0.82, 1, true)
    GameTooltip:AddLine("10 ranks = 10.46% total bonus.", 0.65, 0.82, 1, true)
    GameTooltip:AddLine("Click to purchase for 1 Paragon point when unlocked.", 0.7, 0.85, 1, true)
end)
coreButton:SetScript("OnClick", function()
    local branchNodes = (progress.caster or 0) + (progress.melee or 0) +
        (progress.defensive or 0) + (progress.utility or 0)
    if branchNodes >= 45 then
        requestPurchase("core")
    end
end)
local coreState = createNodeState(coreButton, 0.42)

for _, branch in ipairs(BRANCHES) do
    local currentBranch = branch
    addHotspot(94, currentBranch.y, 112, 118, function()
        GameTooltip:SetText(currentBranch.name, currentBranch.color[1], currentBranch.color[2], currentBranch.color[3])
        GameTooltip:AddLine("15 upgrades. Hover each node to see its effect.", 0.85, 0.85, 0.85, true)
    end)
end

local levelText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
levelText:SetFont("Fonts\\MORPHEUS.TTF", height * 30 / ART_HEIGHT, "OUTLINE")
levelText:SetPoint("TOPRIGHT", frame, "TOPLEFT", width * 1573 / ART_WIDTH, -height * 65 / ART_HEIGHT)
levelText:SetWidth(width * 350 / ART_WIDTH)
levelText:SetJustifyH("CENTER")
levelText:SetTextColor(0.8, 0.9, 1)
local coreText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
coreText:SetFont("Fonts\\MORPHEUS.TTF", height * 25 / ART_HEIGHT, "OUTLINE")
coreText:SetPoint("TOPRIGHT", frame, "TOPLEFT", width * 1573 / ART_WIDTH, -height * 104 / ART_HEIGHT)
coreText:SetWidth(width * 350 / ART_WIDTH)
coreText:SetJustifyH("CENTER")
coreText:SetTextColor(0.55, 0.78, 1)
local pointsText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
pointsText:SetFont("Fonts\\MORPHEUS.TTF", height * 23 / ART_HEIGHT, "OUTLINE")
pointsText:SetPoint("TOPRIGHT", frame, "TOPLEFT", width * 1573 / ART_WIDTH, -height * 142 / ART_HEIGHT)
pointsText:SetWidth(width * 350 / ART_WIDTH)
pointsText:SetJustifyH("CENTER")
pointsText:SetTextColor(0.86, 0.91, 1)

local refundButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
refundButton:SetSize(width * 132 / ART_WIDTH, height * 36 / ART_HEIGHT)
refundButton:SetPoint("TOPLEFT", frame, "TOPLEFT", width * 1075 / ART_WIDTH, -height * 51 / ART_HEIGHT)
refundButton:SetText("Refund All")
refundButton:SetScript("OnClick", function()
    if progress.characterLevel >= 80 and not waitingSequence then
        waitingCommand = "refund"
        waitingSequence = sendParagonCommand("refund")
        commandElapsed = 0
    end
end)
refundButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText("Refund All Paragon Upgrades", 0.8, 0.9, 1)
    GameTooltip:AddLine("Returns every spent point and keeps your Paragon level and XP.", 0.9, 0.9, 0.9, true)
    GameTooltip:Show()
end)
refundButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

-- Drag from the title area without interfering with the node click targets.
local dragHandle = CreateFrame("Button", nil, frame)
dragHandle:SetSize(width * 520 / ART_WIDTH, height * 58 / ART_HEIGHT)
dragHandle:SetPoint("TOPLEFT", frame, "TOPLEFT", width * 400 / ART_WIDTH, -height * 22 / ART_HEIGHT)
dragHandle:EnableMouse(true)
dragHandle:RegisterForDrag("LeftButton")
dragHandle:SetScript("OnDragStart", function() frame:StartMoving() end)
dragHandle:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)

local closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeButton:SetSize(30, 30)
closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -14)
closeButton:SetFrameLevel(frame:GetFrameLevel() + 20)
closeButton:SetScript("OnClick", function() frame:Hide() end)

refreshTree = function()
    local totalPurchased = 0
    for _, branch in ipairs(BRANCHES) do
        local bought = getBranchRanks(branch.key)
        totalPurchased = totalPurchased + bought
    end
    -- Each Paragon level grants one point. Branch ranks and core ranks both spend one.
    local unspentPoints = getUnspentPoints()
    for _, branch in ipairs(BRANCHES) do
        local bought = getBranchRanks(branch.key)
        for rank = 1, 15 do
            local state = nodeStates[branch.key][rank]
            local purchased = rank <= bought
            local isNext = rank == bought + 1
            local canSpend = isNext and progress.characterLevel >= 80 and unspentPoints > 0
            if purchased or canSpend then
                state.dim:Hide()
            else
                state.dim:Show()
            end
            -- Rank 1 is always a branch starting node; only ranks after the next
            -- sequential node carry a lock overlay.
            if rank > 1 and rank > bought + 1 then
                state.lock:Show()
            else
                state.lock:Hide()
            end
        end
    end
    if progress.core > 0 or (progress.characterLevel >= 80 and totalPurchased >= 45 and unspentPoints > 0) then
        coreState.dim:Hide()
    else
        coreState.dim:Show()
    end
    if totalPurchased >= 45 then
        coreState.lock:Hide()
    else
        coreState.lock:Show()
    end
    levelText:SetText("Paragon Level " .. progress.level)
    coreText:SetText("Core Upgrades: " .. progress.core .. " / \226\136\158")
    pointsText:SetText("Unspent Points: " .. unspentPoints)
end

-- Always-visible, independently draggable and resizable progress display.
local xpBar = CreateFrame("Frame", "WoAParagonXPFrame", UIParent)
xpBar:SetSize(WoAParagonDB.width or 360, WoAParagonDB.height or 54)
xpBar:SetFrameStrata("MEDIUM")
xpBar:SetMovable(true)
xpBar:EnableMouse(true)
xpBar:RegisterForDrag("LeftButton")
xpBar:SetPoint("CENTER", UIParent, "CENTER", WoAParagonDB.x or 0, WoAParagonDB.y or screenHeight * 0.38)

xpBar:SetScript("OnDragStart", function(self) self:StartMoving() end)
xpBar:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local x, y = self:GetCenter()
    WoAParagonDB.x, WoAParagonDB.y = x - UIParent:GetWidth() / 2, y - UIParent:GetHeight() / 2
end)

local status = CreateFrame("StatusBar", nil, xpBar)
status:SetPoint("TOPLEFT", xpBar, "TOPLEFT", 4, -4)
status:SetPoint("BOTTOMRIGHT", xpBar, "BOTTOMRIGHT", -4, 4)

-- Draw the metallic border from solid built-in textures. This avoids relying on
-- a custom backdrop file and keeps every edge anchored to the live status bar.
-- The track is anchored to the XP frame's inner corners. The blue fill is sized
-- from the XP fraction below, with a 2-pixel minimum for any positive progress.
local statusBorder = CreateFrame("Frame", nil, xpBar)
statusBorder:SetAllPoints(status)
statusBorder:SetFrameLevel(status:GetFrameLevel() + 4)
statusBorder:EnableMouse(false)
local function metalEdge(pointA, relativePointA, offsetAX, offsetAY, pointB, relativePointB, offsetBX, offsetBY, width, height, r, g, b)
    local edge = statusBorder:CreateTexture(nil, "OVERLAY")
    edge:SetTexture("Interface\\Buttons\\WHITE8X8")
    edge:SetVertexColor(r, g, b, 1)
    edge:SetPoint(pointA, statusBorder, relativePointA, offsetAX, offsetAY)
    edge:SetPoint(pointB, statusBorder, relativePointB, offsetBX, offsetBY)
    if width then edge:SetWidth(width) end
    if height then edge:SetHeight(height) end
    return edge
end
-- A dark steel stroke with bright top/left bevels and shaded bottom/right edges.
metalEdge("TOPLEFT", "TOPLEFT", 0, 0, "TOPRIGHT", "TOPRIGHT", 0, 0, nil, 4, 0.04, 0.07, 0.11)
metalEdge("TOPLEFT", "TOPLEFT", 2, -1, "TOPRIGHT", "TOPRIGHT", -2, -1, nil, 1, 0.88, 0.94, 1)
metalEdge("BOTTOMLEFT", "BOTTOMLEFT", 0, 0, "BOTTOMRIGHT", "BOTTOMRIGHT", 0, 0, nil, 4, 0.04, 0.07, 0.11)
metalEdge("BOTTOMLEFT", "BOTTOMLEFT", 2, 1, "BOTTOMRIGHT", "BOTTOMRIGHT", -2, 1, nil, 1, 0.28, 0.38, 0.49)
metalEdge("TOPLEFT", "TOPLEFT", 0, 0, "BOTTOMLEFT", "BOTTOMLEFT", 0, 0, 4, nil, 0.04, 0.07, 0.11)
metalEdge("TOPLEFT", "TOPLEFT", 1, -4, "BOTTOMLEFT", "BOTTOMLEFT", 1, 4, 1, nil, 0.72, 0.83, 0.94)
metalEdge("TOPRIGHT", "TOPRIGHT", 0, 0, "BOTTOMRIGHT", "BOTTOMRIGHT", 0, 0, 4, nil, 0.04, 0.07, 0.11)
metalEdge("TOPRIGHT", "TOPRIGHT", -1, -4, "BOTTOMRIGHT", "BOTTOMRIGHT", -1, 4, 1, nil, 0.28, 0.38, 0.49)
local statusBg = status:CreateTexture(nil, "BACKGROUND")
statusBg:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
statusBg:SetAllPoints(status)
statusBg:SetVertexColor(0.04, 0.07, 0.12, 1)
local xpFill = status:CreateTexture(nil, "ARTWORK")
xpFill:SetTexture("Interface\\Buttons\\WHITE8X8")
xpFill:SetVertexColor(0.12, 0.52, 1, 1)
xpFill:SetPoint("TOPLEFT", status, "TOPLEFT", 0, 0)
xpFill:SetPoint("BOTTOMLEFT", status, "BOTTOMLEFT", 0, 0)
local xpFraction = 0
local function updateXpFill()
    local trackWidth = math.max(0, status:GetWidth())
    local fillWidth = math.floor(trackWidth * xpFraction + 0.5)
    if xpFraction > 0 and trackWidth > 0 then
        fillWidth = math.max(2, fillWidth)
    end
    fillWidth = math.min(trackWidth, fillWidth)
    xpFill:SetWidth(fillWidth)
    if fillWidth > 0 then xpFill:Show() else xpFill:Hide() end
end
status:SetScript("OnSizeChanged", updateXpFill)
local function setXpProgress(current, maximum)
    current, maximum = tonumber(current) or 0, tonumber(maximum) or 0
    if maximum > 0 then
        xpFraction = math.max(0, math.min(1, current / maximum))
    else
        xpFraction = 0
    end
    updateXpFill()
end
local xpTextLayer = CreateFrame("Frame", nil, xpBar)
xpTextLayer:SetAllPoints(xpBar)
xpTextLayer:SetFrameLevel(xpBar:GetFrameLevel() + 10)
xpTextLayer:EnableMouse(false)
local xpText = xpTextLayer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
xpText:SetPoint("LEFT", xpBar, "LEFT", 12, 0)
xpText:SetPoint("RIGHT", xpBar, "RIGHT", -12, 0)
xpText:SetPoint("CENTER", status, "CENTER", 0, 0)
xpText:SetJustifyH("CENTER")
xpText:SetTextColor(1, 1, 1, 1)
xpText:SetShadowColor(0, 0, 0, 1)
xpText:SetShadowOffset(1, -1)
xpText:SetText("Paragon XP: initializing...")

local resizeGrip = CreateFrame("Button", nil, xpBar)
resizeGrip:SetSize(16, 16)
resizeGrip:SetPoint("BOTTOMRIGHT", status, "BOTTOMRIGHT", -1, 1)
resizeGrip:SetFrameLevel(statusBorder:GetFrameLevel() + 2)
resizeGrip:EnableMouse(true)
resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
resizeGrip:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" then
        local x, y = GetCursorPosition()
        self.dragX, self.dragY = x, y
        self.startWidth, self.startHeight = xpBar:GetWidth(), xpBar:GetHeight()
        self:SetScript("OnUpdate", function(grip)
            local cx, cy = GetCursorPosition()
            local scale = UIParent:GetScale()
            local newWidth = math.max(150, grip.startWidth + (cx - grip.dragX) / scale)
            local newHeight = math.max(32, grip.startHeight - (cy - grip.dragY) / scale)
            xpBar:SetSize(newWidth, newHeight)
            WoAParagonDB.width, WoAParagonDB.height = newWidth, newHeight
        end)
    end
end)
resizeGrip:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)

refreshXpBar = function()
    if progress.characterLevel < 80 then
        xpText:SetText("Paragon " .. progress.level .. "  \226\128\162  Unlocks at level 80")
        setXpProgress(0, 1)
    elseif syncPending then
        xpText:SetText("Paragon XP: syncing from server...")
        setXpProgress(0, 1)
    elseif syncTimedOut then
        xpText:SetText("Paragon XP: server response timed out")
        setXpProgress(0, 1)
    elseif progress.level >= MAX_PARAGON_LEVEL then
        xpText:SetText("Paragon " .. progress.level .. "  •  Maximum level reached")
        setXpProgress(1, 1)
    elseif progress.xpToNext ~= "0" and progress.xpToNext ~= "" then
        xpText:SetText("Paragon " .. progress.level .. "  \226\128\162  " .. progress.currentXp .. " / " .. progress.xpToNext .. " XP")
        setXpProgress(progress.currentXp, progress.xpToNext)
    else
        xpText:SetText("Paragon " .. progress.level .. "  \226\128\162  XP earning not configured")
        setXpProgress(0, 1)
    end
end

local function handleProgressPayload(message)
    if type(message) ~= "string" then return end

    -- 3.3.5 may deliver LANG_ADDON self-whispers either as CHAT_MSG_ADDON
    -- (prefix separated from the body) or as a whisper with the prefix kept
    -- in the text. Accept both representations.
    local prefixedBody = PREFIX .. "\0"
    if string.sub(message, 1, #prefixedBody) == prefixedBody then
        message = string.sub(message, #prefixedBody + 1)
    elseif string.sub(message, 1, #PREFIX + 1) == PREFIX .. "\t" then
        message = string.sub(message, #PREFIX + 2)
    elseif string.sub(message, 1, 12) == "AzerothCore\t" then
        message = string.sub(message, 13)
    end

    -- Addon-command replies use AzerothCore's `mNNNN` sequence envelope.
    -- After removing any prefix above, discard that envelope before parsing
    -- the P| progress record.
    local responseSequence = 0
    if string.sub(message, 1, 1) == "m" and string.sub(message, 2, 5):match("^%d%d%d%d$") then
        responseSequence = tonumber(string.sub(message, 2, 5)) or 0
        message = string.sub(message, 6)
    end

    local fields = {}
    for value in string.gmatch(message, "[^|]+") do table.insert(fields, value) end
    if fields[1] == "E" and #fields >= 9 then
        if responseSequence == 0 or waitingSequence ~= responseSequence or fields[9] ~= UnitName("player") then return end
        local reasons = {
            disabled = "Paragon purchases are disabled on this realm.",
            level = "Paragon purchases require a level 80 character.",
            no_progress = "The server could not load Paragon progress.",
            invalid_branch = "The server received an invalid branch name.",
            branch_complete = "The server says that branch is already complete.",
            previous_nodes = "The server says the previous node is required first.",
            core_locked = "The server says the core is still locked.",
            no_points = "The server sees no unspent Paragon point.",
            database_update = "The server could not save the node purchase.",
            failed = "The server could not complete the node purchase.",
        }
        local detail = reasons[fields[2]] or "The server rejected the node purchase."
        UIErrorsFrame:AddMessage(detail .. " Server ranks: Caster " .. (fields[4] or "?") ..
            ", Melee " .. (fields[5] or "?") .. ", Defensive " .. (fields[6] or "?") ..
            ", Utility " .. (fields[7] or "?") .. ", Core " .. (fields[8] or "?") .. ".",
            1, 0.55, 0.35, 1)
        waitingSequence = nil
        waitingCommand = nil
        commandElapsed = 0
        syncPending = false
        requestProgress()
        return
    end
    if fields[1] ~= "P" or #fields < 11 then return end
    -- Only apply a reply to the command that requested it. The server also
    -- whispers unsolicited XP updates using sequence 0000; ignore those while
    -- a newer sync/purchase/refund is outstanding.
    if responseSequence ~= 0 then
        if waitingSequence ~= responseSequence then return end
    elseif waitingSequence then
        return
    end
    -- A delayed response from the previous character must never overwrite the
    -- build belonging to the character currently in world.
    if fields[11] ~= UnitName("player") then return end

    syncPending = false
    syncTimedOut = false
    waitingSequence = nil
    waitingCommand = nil
    commandElapsed = 0
    progress.characterLevel = tonumber(fields[2]) or UnitLevel("player")
    progress.level = tonumber(fields[3]) or 0
    -- Keep the exact decimal strings for visible text. Lua numbers lose integer
    -- precision long before the late-game XP values become large.
    progress.currentXp = fields[4] or "0"
    progress.xpToNext = fields[5] or "0"
    progress.caster = tonumber(fields[6]) or 0
    progress.melee = tonumber(fields[7]) or 0
    progress.defensive = tonumber(fields[8]) or 0
    progress.utility = tonumber(fields[9]) or 0
    progress.core = tonumber(fields[10]) or 0
    refreshTree(); refreshXpBar()
end

local function handleCommandStatus(message)
    if type(message) ~= "string" then return end
    if string.sub(message, 1, 12) == "AzerothCore\t" then
        message = string.sub(message, 13)
    end
    local opcode = string.sub(message, 1, 1)
    local responseSequence = tonumber(string.sub(message, 2, 5))
    if not responseSequence or responseSequence ~= waitingSequence then return end
    if opcode == "f" then
        local failedCommand = waitingCommand
        waitingSequence = nil
        waitingCommand = nil
        commandElapsed = 0
        syncPending = false
        if failedCommand == "sync" then
            syncTimedOut = true
            refreshXpBar()
        else
            UIErrorsFrame:AddMessage("The server rejected that Paragon action. Data is being resynced.", 1, 0.45, 0.35, 1)
            requestProgress()
        end
    end
end

table.insert(UISpecialFrames, "WoAParagonFrame")
SLASH_WOAPARAGON1 = "/paragon"
SlashCmdList["WOAPARAGON"] = function()
    if frame:IsShown() then frame:Hide() else frame:Show(); requestProgress() end
end

if type(SpellButton_OnClick) == "function" and type(GetSpellBookItemInfo) == "function" then
    hooksecurefunc("SpellButton_OnClick", function(button)
        local bookType = SpellBookFrame and SpellBookFrame.bookType or BOOKTYPE_SPELL
        local itemType, spellID = GetSpellBookItemInfo(button:GetID(), bookType)
        if itemType == "SPELL" and spellID == SPELL_PARAGON then
            frame:Show()
            requestProgress()
        end
    end)
end

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("UNIT_SPELLCAST_SENT")
events:RegisterEvent("UNIT_SPELLCAST_START")
events:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("CHAT_MSG_WHISPER")
events:RegisterEvent("CHAT_MSG_WHISPER_INFORM")
events:RegisterEvent("PLAYER_LEVEL_UP")
events:SetScript("OnEvent", function(_, event, ...)
    local args = { ... }
    local arg1, arg2 = args[1], args[2]
    if event == "ADDON_LOADED" and arg1 == "WoAParagon" then
        RegisterAddonMessagePrefix(PREFIX)
        RegisterAddonMessagePrefix("AzerothCore")
        refreshTree(); refreshXpBar()
        requestProgress()
    elseif event == "PLAYER_ENTERING_WORLD" then
        progress.characterLevel = UnitLevel("player") or 0
        progress.level = 0
        progress.currentXp, progress.xpToNext = "0", "0"
        progress.caster, progress.melee, progress.defensive, progress.utility, progress.core = 0, 0, 0, 0, 0
        xpBar:Show()
        requestProgress()
        refreshTree(); refreshXpBar()
    elseif event == "PLAYER_LEVEL_UP" then
        progress.characterLevel = UnitLevel("player")
        refreshTree(); refreshXpBar()
    elseif event == "CHAT_MSG_ADDON" then
        if arg1 == "AzerothCore" or arg1 == PREFIX then
            handleProgressPayload(arg2)
            handleCommandStatus(arg2)
        end
    elseif event == "CHAT_MSG_WHISPER" or event == "CHAT_MSG_WHISPER_INFORM" then
        handleProgressPayload(arg1)
    elseif (event == "UNIT_SPELLCAST_SENT" or event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_SUCCEEDED") and arg1 == "player" then
        local paragonName = GetSpellInfo(SPELL_PARAGON)
        local isParagonCast = arg2 == paragonName or arg2 == "Paragon"
        for _, value in ipairs(args) do
            if tonumber(value) == SPELL_PARAGON then
                isParagonCast = true
                break
            end
        end
        if isParagonCast then
            frame:Show()
            requestProgress()
        end
    end
end)
events:SetScript("OnUpdate", function(_, elapsed)
    if syncPending then
        syncElapsed = syncElapsed + elapsed
    end
    if waitingSequence then
        commandElapsed = commandElapsed + elapsed
    end
    if waitingSequence and commandElapsed >= 8 then
        local timedOutCommand = waitingCommand
        waitingSequence = nil
        waitingCommand = nil
        commandElapsed = 0
        syncPending = false
        if timedOutCommand == "sync" then
            syncTimedOut = true
            refreshXpBar()
        else
            UIErrorsFrame:AddMessage("Paragon update timed out. Refreshing server data.", 1, 0.75, 0.2, 1)
            requestProgress()
        end
    end
end)
