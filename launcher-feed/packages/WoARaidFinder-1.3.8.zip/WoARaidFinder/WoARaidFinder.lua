-- The 3.3.5 client exposes the custom group header from LFGDungeonGroup.dbc,
-- but its native GetLFDChoiceOrder list omits the raids. Add the raid DBC
-- records to the Specific Dungeons choice list while keeping the native UI.
local raidOrder = {
    48, 50, 160, 161, 42, 44,
    175, 177, 176, 194, 193, 195, 196, 197, 199,
    159, 227, 223, 237, 224, 238, 239, 240, 243, 244, 246, 248,
    247, 250, 46, 257, 279, 280, 293, 294,
}
local raidSet = {}
for _, id in ipairs(raidOrder) do
    raidSet[id] = true
end
local heroicCloneSources = {
    [279] = 300, -- Icecrown Citadel 10-player heroic
    [280] = 301, -- Icecrown Citadel 25-player heroic
    [293] = 302, -- Ruby Sanctum 10-player heroic
    [294] = 303, -- Ruby Sanctum 25-player heroic
}
local heroicBaseById = {}
for normalId, heroicId in pairs(heroicCloneSources) do
    heroicBaseById[heroicId] = normalId
end
local RAID_GROUP_ID = -6
local DEADMINES_ID = 6

local function buildDungeonInfo(id)
    local name, typeID, minLevel, maxLevel, recLevel, minRecLevel, maxRecLevel,
        expansionLevel, groupID, texture, difficulty, maxPlayers = GetLFGDungeonInfo(id)
    if not name then
        return nil
    end
    local size = tonumber(maxPlayers)
    local isHeroic = tonumber(difficulty) == 2 or tonumber(difficulty) == 3
    local sizeLabel = size and size > 0 and tostring(size) or nil
    local displayName = sizeLabel
        and string.format("%s (%s%s)", name, sizeLabel, isHeroic and " Heroic" or "")
        or (isHeroic and string.format("%s (Heroic)", name) or name)
    -- LFG_RETURN_VALUES in 3.3.5: name, type, min/max/rec levels,
    -- expansion, group, texture, difficulty, maxPlayers.
    -- 3.3.5 uses negative IDs for category headers. Keeping the raid group
    -- negative avoids colliding with Deadmines, whose dungeon ID is 6.
    local info = { displayName, typeID, minLevel, maxLevel, recLevel, minRecLevel,
        maxRecLevel, expansionLevel, RAID_GROUP_ID, texture, difficulty, maxPlayers }
    return info, name, size
end

local function removeRaidEntries(list)
    for i = #list, 1, -1 do
        if list[i] == -6 or raidSet[list[i]] then
            table.remove(list, i)
        end
    end
end

local function installRaidChoices(list)
    if type(list) ~= "table" or type(LFGDungeonInfo) ~= "table" then
        return list
    end

    -- Add any missing raid info records. GetLFGDungeonInfo reads the already
    -- loaded client DBC and the server accepts these IDs as dungeon queues.
    local available = {}
    for _, id in ipairs(raidOrder) do
        -- Re-read the base DBC name each time so repeated list refreshes don't
        -- append the size/difficulty suffix more than once.
        local info, name, size = buildDungeonInfo(id)
        if info then
            LFGDungeonInfo[id] = info
            available[#available + 1] = id

            if heroicCloneSources[id] and (tonumber(info[11]) == 0 or tonumber(info[11]) == 1) then
                local heroicId = heroicCloneSources[id]
                local heroicInfo = { unpack(info) }
                heroicInfo[1] = size and string.format("%s (%d Heroic)", name, size)
                    or string.format("%s (Heroic)", name)
                heroicInfo[9] = RAID_GROUP_ID
                heroicInfo[11] = tonumber(info[11]) + 2
                LFGDungeonInfo[heroicId] = heroicInfo
                raidSet[heroicId] = true
                available[#available + 1] = heroicId
            end
        end
    end

    removeRaidEntries(list)
    if #available > 0 and LFGDungeonInfo[-6] then
        list[#list + 1] = RAID_GROUP_ID -- Existing localized header, renamed "Raids" in DBC.
        for _, id in ipairs(available) do
            list[#list + 1] = id
        end
    end
    return list
end

local hooked = false
local reported = false

-- The native client may discard SetLFGDungeon() calls for synthetic IDs that
-- are not in its DBC. Send the real normal slot and carry the selected mode in
-- the client's raid difficulty setting; the server maps it to the heroic ID.
if type(SetLFGDungeon) == "function" and not _G.WoARaidFinderSetDungeonHooked then
    local nativeSetLFGDungeon = SetLFGDungeon
    SetLFGDungeon = function(dungeonId)
        dungeonId = tonumber(dungeonId) or dungeonId
        local normalId = heroicBaseById[dungeonId]
        if normalId then
            local info = LFGDungeonInfo and LFGDungeonInfo[dungeonId]
            local maxPlayers = info and tonumber(info[12]) or 10
            -- The client API is one-based: 1=10N, 2=25N, 3=10H, 4=25H.
            local mode = maxPlayers >= 25 and 4 or 3
            -- The stock LFD join routine calls SetLFGDungeon for each checked
            -- raid immediately before JoinLFG. Set the mode here as well so
            -- the server receives it before the heroic raid's normal DBC slot.
            if type(SetRaidDifficulty) == "function" then
                SetRaidDifficulty(mode)
            end
            if DEFAULT_CHAT_FRAME then
                DEFAULT_CHAT_FRAME:AddMessage(string.format(
                    "WoA Raid Finder: setting %s-player Heroic before queue.",
                    maxPlayers >= 25 and "25" or "10"), 0.2, 0.9, 1)
            end
        end
        return nativeSetLFGDungeon(normalId or dungeonId)
    end
    _G.WoARaidFinderSetDungeonHooked = true
end

if type(JoinLFG) == "function" and not _G.WoARaidFinderJoinHooked then
    local nativeJoinLFG = JoinLFG
    JoinLFG = function(...)
        local selectedRaidMode
        local selectedRaidName
        if type(LFGEnabledList) == "table" then
            for dungeonId, enabled in pairs(LFGEnabledList) do
                if enabled and raidSet[tonumber(dungeonId)] then
                    dungeonId = tonumber(dungeonId)
                    local info = LFGDungeonInfo and LFGDungeonInfo[dungeonId]
                    local difficulty = info and tonumber(info[11]) or 0
                    local maxPlayers = info and tonumber(info[12]) or 10
                    local heroic = heroicBaseById[dungeonId] ~= nil or difficulty >= 2
                    -- SetRaidDifficulty uses client API values 1-4, while the
                    -- server's Difficulty enum uses 0-3. Do not pass the
                    -- server enum directly to the client API.
                    local raidMode = heroic and (maxPlayers >= 25 and 4 or 3)
                        or (maxPlayers >= 25 and 2 or 1)
                    if selectedRaidMode and selectedRaidMode ~= raidMode then
                        if UIErrorsFrame then
                            UIErrorsFrame:AddMessage("Queue raids with one size and difficulty at a time.", 1, 0.1, 0.1, 1)
                        end
                        return
                    end
                    selectedRaidMode = raidMode
                    selectedRaidName = string.format("%s-player %s", maxPlayers >= 25 and "25" or "10",
                        heroic and "Heroic" or "Normal")
                end
            end
        end

        if selectedRaidMode ~= nil then
            if type(SetRaidDifficulty) ~= "function" then
                if UIErrorsFrame then
                    UIErrorsFrame:AddMessage("This client cannot set raid difficulty for Raid Finder.", 1, 0.1, 0.1, 1)
                end
                return
            end
            -- Set the exact WotLK raid difficulty (10 normal, 25 normal,
            -- 10 heroic, 25 heroic) before JoinLFG sends the selected slots.
            SetRaidDifficulty(selectedRaidMode)
            if DEFAULT_CHAT_FRAME and selectedRaidName then
                DEFAULT_CHAT_FRAME:AddMessage("WoA Raid Finder: queuing " .. selectedRaidName .. ".", 0.2, 0.9, 1)
            end
        end

        return nativeJoinLFG(...)
    end
    _G.WoARaidFinderJoinHooked = true
end

local function install()
    if hooked or type(LFGQueueFrame_UpdateLFGDungeonList) ~= "function" then
        return
    end
    -- Clear a stale enabled-state left behind by the old positive group ID,
    -- which shared Deadmines' ID and made its checkbox appear selected.
    if type(SetLFGDungeonEnabled) == "function" then
        SetLFGDungeonEnabled(DEADMINES_ID, false)
    end
    if type(LFGEnabledList) == "table" then
        LFGEnabledList[DEADMINES_ID] = false
    end
    local nativeUpdateDungeonList = LFGQueueFrame_UpdateLFGDungeonList
    LFGQueueFrame_UpdateLFGDungeonList = function(list, hiddenByCollapseList, lockList,
        dungeonInfo, enableList, collapseList, filter)
        if list == LFDDungeonList then
            installRaidChoices(list)
            local raidCount = 0
            for _, id in ipairs(list) do
                if raidSet[id] then raidCount = raidCount + 1 end
            end
            if not reported then
                DEFAULT_CHAT_FRAME:AddMessage("WoA Raid Finder: added " .. raidCount .. " raid choices under Raids.")
                reported = true
            end
            if raidCount == 0 then
                DEFAULT_CHAT_FRAME:AddMessage("WoA Raid Finder: no raid DBC entries were available.")
            end
        end
        return nativeUpdateDungeonList(list, hiddenByCollapseList, lockList,
            dungeonInfo, enableList, collapseList, filter)
    end
    hooked = true
    if type(LFGDungeonList_Setup) == "function" then
        LFGDungeonList_Setup()
    end
    if type(LFDQueueFrame_Update) == "function" and type(LFGDungeonInfo) == "table" then
        LFDQueueFrame_Update()
    end
end

-- Raid groups can hide Blizzard's normal LFG minimap eye even though the
-- server still supports LFG teleport-out. Keep an eye button in the stock
-- eye's position while a finder group is inside an instance.
local function installTeleportOutEye()
    if not MiniMapLFGFrame or _G.WoARaidFinderTeleportOutEye then
        return
    end

    local button = CreateFrame("Button", "WoARaidFinderTeleportOutEye", Minimap)
    button:SetSize(33, 33)
    local function placeButton()
        button:ClearAllPoints()
        local angle = tonumber(WoARaidFinderDB and WoARaidFinderDB.minimapAngle)
        if angle then
            local radius = Minimap:GetWidth() / 2 + 2
            local radians = math.rad(angle)
            button:SetPoint("CENTER", Minimap, "CENTER",
                math.cos(radians) * radius, math.sin(radians) * radius)
        else
            button:SetPoint("TOPLEFT", MiniMapLFGFrame, "TOPLEFT", 0, 0)
        end
    end
    placeButton()
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(MiniMapLFGFrame:GetFrameLevel() + 5)
    button:SetMovable(true)
    button:RegisterForDrag("LeftButton")
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    local eye = button:CreateTexture(nil, "ARTWORK")
    eye:SetTexture("Interface\\LFGFrame\\LFG-Eye")
    eye:SetTexCoord(0, 0.125, 0, 0.25)
    eye:SetSize(30, 30)
    eye:SetPoint("CENTER", button, "CENTER")

    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(52, 52)
    border:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)

    local function update()
        local inInstance = IsInInstance()
        local inFinderGroup = IsPartyLFG()
        if inInstance and inFinderGroup then
            button:Show()
        else
            button:Hide()
        end
    end

    button:SetScript("OnClick", function(_, mouseButton)
        if button.wasDragged then
            button.wasDragged = nil
            return
        end
        if mouseButton == "RightButton" then
            if ToggleLFDParentFrame then
                ToggleLFDParentFrame()
            end
        elseif LFGTeleport then
            LFGTeleport(true)
        end
    end)
    button:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    button:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        local centerX, centerY = Minimap:GetCenter()
        local dx, dy = x - centerX, y - centerY
        if dx * dx + dy * dy > 16 then
            WoARaidFinderDB.minimapAngle = math.deg(math.atan2(dy, dx))
            self.wasDragged = true
        end
        placeButton()
    end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Teleport out of Dungeon or Raid")
        GameTooltip:AddLine("Right-click to open Dungeon Finder", 1, 1, 1)
        GameTooltip:AddLine("Left-click and drag to move", .75, .75, .75)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", GameTooltip_Hide)

    local events = CreateFrame("Frame")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    events:RegisterEvent("PARTY_MEMBERS_CHANGED")
    events:RegisterEvent("LFG_UPDATE")
    events:SetScript("OnEvent", update)
    events:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        if self.elapsed >= 1 then
            self.elapsed = 0
            update()
        end
    end)

    update()
end

local frame = CreateFrame("Frame")
WoARaidFinderDB = type(WoARaidFinderDB) == "table" and WoARaidFinderDB or {}
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function()
    install()
    installTeleportOutEye()
end)
