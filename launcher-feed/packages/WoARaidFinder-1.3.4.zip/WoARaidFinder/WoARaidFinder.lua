-- The 3.3.5 client exposes the custom group header from LFGDungeonGroup.dbc,
-- but its native GetLFDChoiceOrder list omits the raids. Add the raid DBC
-- records to the Specific Dungeons choice list while keeping the native UI.
local raidOrder = {
    48, 50, 160, 161, 42, 44,
    175, 177, 176, 194, 193, 195, 196, 197, 199,
    159, 227, 223, 237, 224, 238, 239, 240, 243, 244, 246, 248,
    247, 250, 46, 257, 279, 280, 293, 294,
}
local raidSet = {}
for _, id in ipairs(raidOrder) do
    raidSet[id] = true
end
local heroicCloneSources = {
    [279] = 300, -- Icecrown Citadel 10-player heroic
    [280] = 301, -- Icecrown Citadel 25-player heroic
    [293] = 302, -- Ruby Sanctum 10-player heroic
    [294] = 303, -- Ruby Sanctum 25-player heroic
}
local heroicBaseById = {}
for normalId, heroicId in pairs(heroicCloneSources) do
    heroicBaseById[heroicId] = normalId
end
local RAID_GROUP_ID = -6
local DEADMINES_ID = 6

local function buildDungeonInfo(id)
    local name, typeID, minLevel, maxLevel, recLevel, minRecLevel, maxRecLevel,
        expansionLevel, groupID, texture, difficulty, maxPlayers = GetLFGDungeonInfo(id)
    if not name then
        return nil
    end
    local size = tonumber(maxPlayers)
    local isHeroic = tonumber(difficulty) == 2 or tonumber(difficulty) == 3
    local sizeLabel = size and size > 0 and tostring(size) or nil
    local displayName = sizeLabel
        and string.format("%s (%s%s)", name, sizeLabel, isHeroic and " Heroic" or "")
        or (isHeroic and string.format("%s (Heroic)", name) or name)
    -- LFG_RETURN_VALUES in 3.3.5: name, type, min/max/rec levels,
    -- expansion, group, texture, difficulty, maxPlayers.
    -- 3.3.5 uses negative IDs for category headers. Keeping the raid group
    -- negative avoids colliding with Deadmines, whose dungeon ID is 6.
    local info = { displayName, typeID, minLevel, maxLevel, recLevel, minRecLevel,
        maxRecLevel, expansionLevel, RAID_GROUP_ID, texture, difficulty, maxPlayers }
    return info, name, size
end

local function removeRaidEntries(list)
    for i = #list, 1, -1 do
        if list[i] == -6 or raidSet[list[i]] then
            table.remove(list, i)
        end
    end
end

local function installRaidChoices(list)
    if type(list) ~= "table" or type(LFGDungeonInfo) ~= "table" then
        return list
    end

    -- Add any missing raid info records. GetLFGDungeonInfo reads the already
    -- loaded client DBC and the server accepts these IDs as dungeon queues.
    local available = {}
    for _, id in ipairs(raidOrder) do
        -- Re-read the base DBC name each time so repeated list refreshes don't
        -- append the size/difficulty suffix more than once.
        local info, name, size = buildDungeonInfo(id)
        if info then
            LFGDungeonInfo[id] = info
            available[#available + 1] = id

            if heroicCloneSources[id] and (tonumber(info[11]) == 0 or tonumber(info[11]) == 1) then
                local heroicId = heroicCloneSources[id]
                local heroicInfo = { unpack(info) }
                heroicInfo[1] = size and string.format("%s (%d Heroic)", name, size)
                    or string.format("%s (Heroic)", name)
                heroicInfo[9] = RAID_GROUP_ID
                heroicInfo[11] = tonumber(info[11]) + 2
                LFGDungeonInfo[heroicId] = heroicInfo
                raidSet[heroicId] = true
                available[#available + 1] = heroicId
            end
        end
    end

    removeRaidEntries(list)
    if #available > 0 and LFGDungeonInfo[-6] then
        list[#list + 1] = RAID_GROUP_ID -- Existing localized header, renamed "Raids" in DBC.
        for _, id in ipairs(available) do
            list[#list + 1] = id
        end
    end
    return list
end

local hooked = false
local reported = false

-- The native client may discard SetLFGDungeon() calls for synthetic IDs that
-- are not in its DBC. Send the real normal slot and carry the selected mode in
-- the client's raid difficulty setting; the server maps it to the heroic ID.
if type(SetLFGDungeon) == "function" and not _G.WoARaidFinderSetDungeonHooked then
    local nativeSetLFGDungeon = SetLFGDungeon
    SetLFGDungeon = function(dungeonId)
        local normalId = heroicBaseById[tonumber(dungeonId)]
        return nativeSetLFGDungeon(normalId or dungeonId)
    end
    _G.WoARaidFinderSetDungeonHooked = true
end

if type(JoinLFG) == "function" and not _G.WoARaidFinderJoinHooked then
    local nativeJoinLFG = JoinLFG
    JoinLFG = function(...)
        local selectedNormal, selectedHeroic = false, false
        local queueFrame = _G.LFGQueueFrame or _G.LFDQueueFrame
        if (not queueFrame or queueFrame.type == "specific") and type(LFGEnabledList) == "table" then
            for dungeonId, enabled in pairs(LFGEnabledList) do
                if enabled and raidSet[tonumber(dungeonId)] then
                    local info = LFGDungeonInfo and LFGDungeonInfo[tonumber(dungeonId)]
                    local difficulty = info and tonumber(info[11]) or 0
                    if heroicBaseById[tonumber(dungeonId)] or difficulty >= 2 then
                        selectedHeroic = true
                    else
                        selectedNormal = true
                    end
                end
            end
        end

        if selectedNormal and selectedHeroic then
            if UIErrorsFrame then
                UIErrorsFrame:AddMessage("Select normal or heroic raids, not both.", 1, 0.1, 0.1, 1)
            end
            return
        end

        if selectedHeroic and type(SetRaidDifficulty) == "function" then
            SetRaidDifficulty(2) -- Heroic mode; the server derives 10/25 from the selected raid.
        elseif selectedNormal and type(SetRaidDifficulty) == "function" then
            SetRaidDifficulty(0) -- Prevent a previous heroic setting changing normal selections.
        end

        return nativeJoinLFG(...)
    end
    _G.WoARaidFinderJoinHooked = true
end

local function install()
    if hooked or type(LFGQueueFrame_UpdateLFGDungeonList) ~= "function" then
        return
    end
    -- Clear a stale enabled-state left behind by the old positive group ID,
    -- which shared Deadmines' ID and made its checkbox appear selected.
    if type(SetLFGDungeonEnabled) == "function" then
        SetLFGDungeonEnabled(DEADMINES_ID, false)
    end
    if type(LFGEnabledList) == "table" then
        LFGEnabledList[DEADMINES_ID] = false
    end
    local nativeUpdateDungeonList = LFGQueueFrame_UpdateLFGDungeonList
    LFGQueueFrame_UpdateLFGDungeonList = function(list, hiddenByCollapseList, lockList,
        dungeonInfo, enableList, collapseList, filter)
        if list == LFDDungeonList then
            installRaidChoices(list)
            local raidCount = 0
            for _, id in ipairs(list) do
                if raidSet[id] then raidCount = raidCount + 1 end
            end
            if not reported then
                DEFAULT_CHAT_FRAME:AddMessage("WoA Raid Finder: added " .. raidCount .. " raid choices under Raids.")
                reported = true
            end
            if raidCount == 0 then
                DEFAULT_CHAT_FRAME:AddMessage("WoA Raid Finder: no raid DBC entries were available.")
            end
        end
        return nativeUpdateDungeonList(list, hiddenByCollapseList, lockList,
            dungeonInfo, enableList, collapseList, filter)
    end
    hooked = true
    if type(LFGDungeonList_Setup) == "function" then
        LFGDungeonList_Setup()
    end
    if type(LFDQueueFrame_Update) == "function" and type(LFGDungeonInfo) == "table" then
        LFDQueueFrame_Update()
    end
end

-- Raid groups can hide Blizzard's normal LFG minimap eye even though the
-- server still supports LFG teleport-out. Keep an eye button in the stock
-- eye's position while a finder group is inside an instance.
local function installTeleportOutEye()
    if not MiniMapLFGFrame or _G.WoARaidFinderTeleportOutEye then
        return
    end

    local button = CreateFrame("Button", "WoARaidFinderTeleportOutEye", Minimap)
    button:SetSize(33, 33)
    button:SetPoint("TOPLEFT", MiniMapLFGFrame, "TOPLEFT", 0, 0)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(MiniMapLFGFrame:GetFrameLevel() + 5)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    local eye = button:CreateTexture(nil, "ARTWORK")
    eye:SetTexture("Interface\\LFGFrame\\LFG-Eye")
    eye:SetTexCoord(0, 0.125, 0, 0.25)
    eye:SetSize(30, 30)
    eye:SetPoint("CENTER", button, "CENTER")

    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(52, 52)
    border:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)

    local function update()
        local inInstance = IsInInstance()
        local inFinderGroup = IsPartyLFG()
        if inInstance and inFinderGroup then
            button:Show()
        else
            button:Hide()
        end
    end

    button:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "RightButton" then
            if ToggleLFDParentFrame then
                ToggleLFDParentFrame()
            end
        elseif LFGTeleport then
            LFGTeleport(true)
        end
    end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Teleport out of Dungeon or Raid")
        GameTooltip:AddLine("Right-click to open Dungeon Finder", 1, 1, 1)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", GameTooltip_Hide)

    local events = CreateFrame("Frame")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    events:RegisterEvent("PARTY_MEMBERS_CHANGED")
    events:RegisterEvent("LFG_UPDATE")
    events:SetScript("OnEvent", update)
    events:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        if self.elapsed >= 1 then
            self.elapsed = 0
            update()
        end
    end)

    update()
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function()
    install()
    installTeleportOutEye()
end)
